package testRunner;

import io.cucumber.junit.Cucumber;
import cucumber.api.CucumberOptions;
import org.junit.runner.RunWith;



@RunWith(Cucumber.class)
@CucumberOptions(
		features = "/com.NEWSvalidation/src/main/java/Feature/fakeNews.feature", 
		glue={"stepDefinitions"}, 
		plugin= {"pretty","html:test-outout", "json:json_output/cucumber.json", "junit:junit_xml/cucumber.xml"}, 
		monochrome = true, 
		strict = true, 
		dryRun = false 
		//tags = {"~@SmokeTest" , "~@RegressionTest", "~@End2End"}			
		)

public class TestRunner {

}
