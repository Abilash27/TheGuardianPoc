package stepDefinitions;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class EnvironmentSetup {

	WebDriver driver;
	Properties prop;
	
	public void setup(String browser, String URL) {
		
		if(browser.equals("Chrome")) {
			System.setProperty("webdriver.chrome.driver", "");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get(URL);
			}
		else if(browser.equals("IE")) {
			System.setProperty("webdriver.ie.driver", "");
			driver = new InternetExplorerDriver();
			driver.manage().window().maximize();
			driver.get(URL);
		}
		else if(browser.equals("Firefox")){
			System.setProperty("webdriver.firefox.marionette", "");
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.get(URL);
		}
		else {
			
		}
			
	}
	
	public void loadProperty() {
		prop = new Properties();
		
		 try (InputStream input = new FileInputStream("path/to/config.properties")) {
			 	prop = new Properties();

	            prop.load(input);
		 	} catch (IOException ex) {
	            ex.printStackTrace();
	        }
	}
	
	
	
}
