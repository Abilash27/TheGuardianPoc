$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Feature/theGuardian.feature");
formatter.feature({
  "name": "Fake news",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@fakenews"
    }
  ]
});
formatter.scenario({
  "name": "To validate news publish in The Guardian is valid",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@fakenews"
    },
    {
      "name": "@smoke"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "user is on The Guardian news page",
  "keyword": "Given "
});
formatter.match({
  "location": "TestSteps.user_is_on_The_Guardian_news_page()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Navigate to UK Edition",
  "keyword": "And "
});
formatter.match({
  "location": "TestSteps.navigate_to_UK_Edition()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user naviage to first news",
  "keyword": "When "
});
formatter.match({
  "location": "TestSteps.user_naviage_to_first_news()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "read the headline of the news",
  "keyword": "Then "
});
formatter.match({
  "location": "TestSteps.read_the_headline_of_the_news()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "compare the news published with google search results",
  "keyword": "Then "
});
formatter.match({
  "location": "TestSteps.compare_the_news_published_with_google_search_results()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});