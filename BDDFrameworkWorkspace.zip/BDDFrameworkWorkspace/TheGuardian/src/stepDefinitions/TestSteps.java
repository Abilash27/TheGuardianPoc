package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps {
	
WebDriver driver;
	


@Before
public void setenvironment() {
	System.setProperty("webdriver.chrome.driver","E:\\BDDFrameworkWorkspace\\TheGuardian\\src\\drivers\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();
}
	
@After
public void closebrowser() {
	driver.quit();
}
	
	@Given("^user is on The Guardian news page$")
	public void user_is_on_The_Guardian_news_page() {
	    driver.get("https://www.theguardian.com/tone/news");
		driver.findElement(By.xpath("//button[@data-link-name='first-pv-consent : agree']")).click();
	}

	@Given("^Navigate to UK Edition$")
	public void navigate_to_UK_Edition() {
	   WebElement edition = driver.findElement(By.id("edition-picker-toggle"));
	    String[] editionversion = edition.getText().split("\\n");
	   
	   if(!editionversion[1].equals("UK edition")) {
		   edition.click();
		   WebElement editiondropdown = driver.findElement(By.id("edition-dropdown-menu"));
		   List<WebElement> dropdownlist = editiondropdown.findElements(By.tagName("li"));
		for(WebElement value:dropdownlist) {
			String[] dropdownval = value.getText().split("\\n");
			
			if(dropdownval[1].equals("UK edition")) {
				value.click();
				break;
					
			}
	   }
	  
	   }
	}
	
	@When("^user naviage to first news$")
	public void user_naviage_to_first_news() {
	
		driver.findElement(By.xpath("(//div[@class='fc-item__container'])[1]")).click();
		
	}

	public static String headline;  
	@Then("^read the headline of the news$")
	public void read_the_headline_of_the_news() {
		
		headline = driver.findElement(By.xpath("//h1[@class='content__headline ']")).getText();
	   
	}

	@Then("^compare the news published with google search results$")
	public void compare_the_news_published_with_google_search_results() {
		driver.get("https://www.google.com/");
		driver.findElement(By.xpath("//input[@title='Search']")).sendKeys(headline);
		driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@value='Google Search']")).click();
		List<WebElement> newsresult =driver.findElements(By.xpath("//a[@href]/h3"));
		
	   	}

}
